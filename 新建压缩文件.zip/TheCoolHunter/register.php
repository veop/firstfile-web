<html>
	<head>
		<?php
			class A{
				function function1(){
					echo '<script language="JavaScript">;alert("register successfully!");location.href="login.html";</script>;';
				}
				function function2(){
					echo '<script language="JavaScript">;alert("this account is exiting !");location.href="register.html";</script>;';
				}
			}
		?>
	</head>
	<body>
		<?php
			$username=$_POST["name"];
			$password1=$_POST["password1"];
			$temp=$_POST["address"];
			if($temp==2){
				$address="Beijing";
			} elseif($temp==3){
				$address="Shanghai";
			}  elseif($temp==4){
				$address="Sichuan";
			}  elseif($temp==5){
				$address="Tianjing";
			} 
		?>
		<?php
			$link=mysql_connect("localhost","root","root");
			if($link){
				//echo "connect successfully!";
			}
			$db_selected=mysql_select_db("text2",$link);
			$sql1="select * from tb_user where username= '$username'";
			$result1=mysql_query($sql1,$link);
			$num1=mysql_num_rows($result1);
			echo $num1;
			$newa=new A();
			if ($num1>0) {	
				$newa->function2();
				mysql_close($link);
			} else {
				$sql="insert into tb_user(username,password,address) values('$username','$password1','$address')";
				$result=mysql_query($sql,$link);
				$newa->function1();
				mysql_close($link);
			}
		?>
	</body>
</html>