<html>
	<head>
		<?php
			class A{
				function function1(){
					echo '<script language="JavaScript">;alert("log in successfully!");location.href="cool-1.html";</script>;';
				}
				function function2(){
					echo '<script language="JavaScript">;alert("account or password error!");location.href="login.html";</script>;';
				}
			}			
		?>
	</head>
	<body>
		<?php
			$username=$_POST["username"];
			$password=$_POST["password"];
			//echo $username;
		?>
		<?php
			$link=mysql_connect("localhost","root","root");
			if($link){
				//echo "successfully!";
			}
			$db_selected=mysql_select_db("text2",$link);	

			$sql="select * from tb_user where username= '$username' and password='$password'";
			$result=mysql_query($sql,$link);
			$num=mysql_num_rows($result);
			//echo $num;
			mysql_close($link);
			$newa=new A();
			if($num>0){
				$newa->function1();
			}
			else{
				$newa->function2();
			}	
		?>
	</body>
</html>