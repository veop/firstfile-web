var curIndex=1;//初始换显示第一张
    function slideTo (index) {
        var index = parseInt(index);
        var pic = document.getElementById("slideshow_photo").childNodes;
        for(var i=0;i<pic.length;i++){//改变zIndex属性
            if(pic[i].attributes && pic[i].attributes['index'] && parseInt(pic[i].attributes['index'].value)==index){
                pic[i].style.zIndex=2;
                curIndex=index;
            }
            else if(pic[i].attributes && pic[i].attributes['index']) {
                pic[i].style.zIndex=1;
            }
        }
        var bts = document.getElementsByClassName("slideshow-bt");
        for(var i=0;i<bts.length;i++){//改变显示的效果
            if(parseInt(bts[i].attributes['index'].value)==index){
                bts[i].className="slideshow-bt bt-on";
            }
            else bts[i].className = "slideshow-bt";
        }
    }
    window.onload = function  () {    //为按钮初始化onclick事件
        var bts = document.getElementsByClassName("slideshow-bt");
        for(var i=0;i<bts.length;i++){
            bts[i].onclick = function  () {
                slideTo(this.attributes['index'].value);
            }
        }
    }
    setInterval(function  () {//循环切换
        if(curIndex+1>5) curIndex=0;
        slideTo(curIndex+1);
    },2000);
//  图片轮播结束

$(function() {
                //获取按钮并设置点击事件
                $("button").click(function() {
                    switch($(this).html()) {
                        case "&lt;":
                        $(".hide-and-show").hide(500);
                            break;
                        case "&gt;":
                        //显示
                        //$("img").show(500);
                        //下来效果显示
                        $(".hide-and-show").slideDown(1000);
                            break;
                        case "切换":
                        //$("img").toggle(500);
                        //渐变效果切换
                        $("img").fadeToggle("slow");
                            break;
                    }
                });
           });
//隐藏显示按钮结束     

/*鼠标悬停改变另外一个div的样式.......没写*/
$(".stand-bottom").scrollTop();
//滚动条